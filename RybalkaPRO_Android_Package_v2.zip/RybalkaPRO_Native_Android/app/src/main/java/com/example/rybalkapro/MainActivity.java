package com.example.rybalkapro;

import android.app.Activity;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.pm.ActivityInfo;

public class MainActivity extends Activity {
  GameView game; TextView status; int fish=0, money=0; boolean cast=false;
  @Override public void onCreate(Bundle b){super.onCreate(b);setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
    getWindow().getDecorView().setSystemUiVisibility(5894|1024|512|4096);
    FrameLayout root=new FrameLayout(this); game=new GameView(this);root.addView(game);
    LinearLayout hud=new LinearLayout(this);hud.setOrientation(LinearLayout.VERTICAL);hud.setPadding(22,12,22,12);hud.setBackgroundColor(0x99081720);
    status=new TextView(this);status.setTextColor(Color.WHITE);status.setTextSize(16);status.setTypeface(null,Typeface.BOLD);status.setText("🎣 РЫБАЛКА PRO 3D     💰 0 €     🐟 0");hud.addView(status);
    FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.LEFT);hp.setMargins(14,14,0,0);root.addView(hud,hp);
    Button action=new Button(this);action.setText("ЗАБРОСИТЬ");action.setTextSize(15);action.setAllCaps(false);
    FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(-2,-2,Gravity.RIGHT|Gravity.BOTTOM);ap.setMargins(0,0,22,22);root.addView(action,ap);
    action.setOnClickListener(v->{if(!cast){cast=true;game.renderer.cast=true;action.setText("ПОДСЕЧЬ / КРУТИТЬ");}else{if(game.renderer.bite){fish++;money+=10+(int)(Math.random()*15);status.setText("🎣 РЫБАЛКА PRO 3D     💰 "+money+" €     🐟 "+fish);Toast.makeText(this,"Есть рыба! +деньги",Toast.LENGTH_SHORT).show();}else Toast.makeText(this,"Пока нет поклёвки — подожди",Toast.LENGTH_SHORT).show();cast=false;game.renderer.cast=false;game.renderer.bite=false;action.setText("ЗАБРОСИТЬ");}});
    setContentView(root);
  }
  @Override protected void onPause(){super.onPause();if(game!=null)game.onPause();}
  @Override protected void onResume(){super.onResume();if(game!=null)game.onResume();}
  class GameView extends GLSurfaceView {
    NativeRenderer renderer; float downX,downY; boolean joystick=false;
    GameView(Activity a){super(a);setEGLContextClientVersion(2);renderer=new NativeRenderer();setRenderer(renderer);setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);}
    @Override public boolean onTouchEvent(android.view.MotionEvent e){float x=e.getX(),y=e.getY();switch(e.getActionMasked()){
      case MotionEvent.ACTION_DOWN: downX=x;downY=y;joystick=x<getWidth()*.35f && y>getHeight()*.45f; if(joystick)move(x,y);return true;
      case MotionEvent.ACTION_MOVE: if(joystick)move(x,y);else{renderer.yaw+=(x-downX)*.006f;renderer.pitch=Math.max(-.45f,Math.min(.45f,renderer.pitch+(y-downY)*.003f));downX=x;downY=y;}return true;
      case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL: joystick=false;renderer.moveX=renderer.moveZ=0;return true;
    }return true;}
    void move(float x,float y){float dx=(x-downX)/100f,dy=(y-downY)/100f;renderer.moveX=Math.max(-1,Math.min(1,dx));renderer.moveZ=Math.max(-1,Math.min(1,dy));}
  }
}
