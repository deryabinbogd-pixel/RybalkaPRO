package com.example.rybalkapro;
import android.opengl.GLES20;import android.opengl.GLSurfaceView;import android.opengl.Matrix;import java.nio.*;import java.util.*;

public class NativeRenderer implements GLSurfaceView.Renderer {
 int program;float yaw=0,pitch=0,moveX=0,moveZ=0,px=0,pz=5;boolean cast=false,bite=false;long start;float[] view=new float[16],proj=new float[16],vp=new float[16],model=new float[16],mvp=new float[16];
 int pos,color;ArrayList<Fish> fishes=new ArrayList<>();Random rnd=new Random(8);
 static class Fish{float x,y,z,s,phase;Fish(float a,float b,float c,float d,float e){x=a;y=b;z=c;s=d;phase=e;}}
 final String VS="attribute vec3 aPos; uniform mat4 uMVP; void main(){gl_Position=uMVP*vec4(aPos,1.0);}";
 final String FS="precision mediump float; uniform vec4 uColor; void main(){gl_FragColor=uColor;}";
 public void onSurfaceCreated(javax.microedition.khronos.opengles.GL10 g,javax.microedition.khronos.egl.EGLConfig c){GLES20.glClearColor(.55f,.76f,.82f,1);GLES20.glEnable(GLES20.GL_DEPTH_TEST);program=GLES20.glCreateProgram();int v=shader(35633,VS),f=shader(35632,FS);GLES20.glAttachShader(program,v);GLES20.glAttachShader(program,f);GLES20.glLinkProgram(program);pos=GLES20.glGetAttribLocation(program,"aPos");color=GLES20.glGetUniformLocation(program,"uColor");for(int i=0;i<18;i++)fishes.add(new Fish((rnd.nextFloat()-.5f)*23,-.6f-rnd.nextFloat()*1.3f,-8-rnd.nextFloat()*35,.35f+rnd.nextFloat()*.5f,rnd.nextFloat()*6.28f));start=System.currentTimeMillis();}
 int shader(int type,String src){int s=GLES20.glCreateShader(type);GLES20.glShaderSource(s,src);GLES20.glCompileShader(s);return s;}
 public void onSurfaceChanged(javax.microedition.khronos.opengles.GL10 g,int w,int h){GLES20.glViewport(0,0,w,h);Matrix.perspectiveM(proj,0,68,(float)w/h,.1f,150);}
 public void onDrawFrame(javax.microedition.khronos.opengles.GL10 g){long now=System.currentTimeMillis();float t=(now-start)/1000f;GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);px+=(-moveX*(float)Math.cos(yaw)-moveZ*(float)Math.sin(yaw))*.075f;pz+=(-moveZ*(float)Math.cos(yaw)+moveX*(float)Math.sin(yaw))*.075f;px=Math.max(-22,Math.min(22,px));pz=Math.max(-12,Math.min(15,pz));
 float[] eye={px,1.65f,pz},center={px+(float)Math.sin(yaw),1.65f+(float)Math.sin(pitch),pz-(float)Math.cos(yaw)};Matrix.setLookAtM(view,0,eye[0],eye[1],eye[2],center[0],center[1],center[2],0,1,0);Matrix.multiplyMM(vp,0,proj,0,view,0);
 // grassy shore, lake and far banks
 box(0,-.35f,1,90,.5f,90,new float[]{.25f,.38f,.18f,1});box(0,-.20f,-28,90,.12f,54,new float[]{.06f,.36f,.48f,1});
 // animated water ripple strips
 for(int i=0;i<14;i++){float z=-7-i*3.1f;float x=(float)Math.sin(t*1.1f+i)*7;box(x,-.115f,z,3.2f,.018f,.035f,new float[]{.36f,.72f,.78f,.72f});}
 // tree trunks and stylized pine crowns on shore
 for(int i=0;i<18;i++){float x=-28+i*3.3f;tree(x,8+(i%3)*2);tree(x,-63+(i%4)*2);}
 // fish swim under water with simple body, tail and eye geometry
 for(Fish q:fishes){float fx=q.x+(float)Math.sin(t*.45f+q.phase)*2.1f,fz=q.z+(float)Math.cos(t*.3f+q.phase)*1.2f;ellipsoid(fx,q.y+(float)Math.sin(t+q.phase)*.12f,fz,q.s*1.35f,q.s*.42f,q.s*.5f,new float[]{.72f,.57f,.28f,1});tri(new float[]{fx-q.s*1.1f,q.y,fz,fx-q.s*1.85f,q.y+q.s*.4f,fz,fx-q.s*1.85f,q.y-q.s*.4f,fz},new float[]{.85f,.68f,.34f,1});ellipsoid(fx+q.s*.75f,q.y+.1f,fz+q.s*.4f,.055f,.055f,.055f,new float[]{.02f,.02f,.02f,1});}
 // bubbles / glitter motes
 for(int i=0;i<75;i++){float x=(float)Math.sin(i*13.7+t*.22f)*12,z=-7-(i*17%48),y=-.05f+(float)((t*.55f+i*.19f)%3.6);ellipsoid(x,y,z,.025f,.025f,.025f,new float[]{.72f,.94f,1,.8f});}
 if(cast){float bx=px+(float)Math.sin(yaw)*10,bz=pz-(float)Math.cos(yaw)*10;ellipsoid(bx,-.04f+(float)Math.sin(t*3)*.04f,bz,.14f,.16f,.14f,new float[]{1,.22f,.08f,1});if(t%12<.035f)bite=true;}
 }
 void tree(float x,float z){box(x,1.0f,z,.22f,2,.22f,new float[]{.28f,.17f,.09f,1});cone(x,3,z,1.5f,2.6f,new float[]{.12f,.32f,.16f,1});cone(x,4.2f,z,1.1f,2.1f,new float[]{.16f,.4f,.19f,1});}
 void box(float x,float y,float z,float sx,float sy,float sz,float[] c){float[] a={-1,-1,-1,1,-1,-1,1,1,-1,-1,1,-1,-1,-1,1,1,-1,1,1,1,1,-1,1,1};float[] v=new float[36*3];int[] ix={0,1,2,0,2,3,4,6,5,4,7,6,0,4,5,0,5,1,3,2,6,3,6,7,1,5,6,1,6,2,0,3,7,0,7,4};for(int i=0;i<36;i++){int k=ix[i]*3;v[i*3]=a[k]*sx+x;v[i*3+1]=a[k+1]*sy+y;v[i*3+2]=a[k+2]*sz+z;}draw(v,c, GLES20.GL_TRIANGLES);}
 void cone(float x,float y,float z,float r,float h,float[] c){float[] v=new float[18*3];for(int i=0;i<6;i++){double a=i*Math.PI/3,b=(i+1)*Math.PI/3;int k=i*9;v[k]=x;v[k+1]=y+h/2;v[k+2]=z;v[k+3]=(float)(x+Math.cos(a)*r);v[k+4]=y-h/2;v[k+5]=(float)(z+Math.sin(a)*r);v[k+6]=(float)(x+Math.cos(b)*r);v[k+7]=y-h/2;v[k+8]=(float)(z+Math.sin(b)*r);}draw(v,c,GLES20.GL_TRIANGLES);}
 void ellipsoid(float x,float y,float z,float rx,float ry,float rz,float[] c){int lat=6,lon=10;float[] v=new float[lat*lon*6*3];int n=0;for(int a=0;a<lat;a++)for(int b=0;b<lon;b++){float p1=(float)(Math.PI*a/lat-Math.PI/2),p2=(float)(Math.PI*(a+1)/lat-Math.PI/2),q1=(float)(2*Math.PI*b/lon),q2=(float)(2*Math.PI*(b+1)/lon);float[][] pts={pt(x,y,z,rx,ry,rz,p1,q1),pt(x,y,z,rx,ry,rz,p2,q1),pt(x,y,z,rx,ry,rz,p2,q2),pt(x,y,z,rx,ry,rz,p1,q1),pt(x,y,z,rx,ry,rz,p2,q2),pt(x,y,z,rx,ry,rz,p1,q2)};for(float[] p:pts){v[n++]=p[0];v[n++]=p[1];v[n++]=p[2];}}draw(v,c,GLES20.GL_TRIANGLES);}
 float[] pt(float x,float y,float z,float rx,float ry,float rz,float p,float q){return new float[]{x+rx*(float)Math.cos(p)*(float)Math.cos(q),y+ry*(float)Math.sin(p),z+rz*(float)Math.cos(p)*(float)Math.sin(q)};}
 void tri(float[] v,float[] c){draw(v,c,GLES20.GL_TRIANGLES);}
 void draw(float[] verts,float[] c,int mode){FloatBuffer b=ByteBuffer.allocateDirect(verts.length*4).order(ByteOrder.nativeOrder()).asFloatBuffer();b.put(verts).position(0);GLES20.glUseProgram(program);GLES20.glEnableVertexAttribArray(pos);GLES20.glVertexAttribPointer(pos,3,GLES20.GL_FLOAT,false,0,b);GLES20.glUniform4fv(color,1,c,0);GLES20.glDrawArrays(mode,0,verts.length/3);GLES20.glDisableVertexAttribArray(pos);}
}
